SET NAMES utf8;

SET SQL_MODE='';

SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

/*Data for the table `linkdef` */

LOCK TABLES `linkdef` WRITE;

insert into `linkdef` (`linkid`,`name`,`recurses`) values ('1','hypernym','Y');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('2','hyponym','Y');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('3','instance hypernym','Y');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('4','instance hyponym','Y');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('11','part holonym','Y');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('12','part meronym','Y');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('13','member holonym','Y');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('14','member meronym','Y');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('15','substance holonym','Y');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('16','substance meronym','Y');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('21','entail','Y');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('23','cause','Y');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('30','antonym','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('40','similar','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('50','also','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('60','attribute','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('70','verb group','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('71','participle','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('80','pertainym','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('81','derivation','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('91','domain category','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('92','domain member category','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('93','domain region','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('94','domain member region','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('95','domain usage','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('96','domain member usage','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('97','domain','N');
insert into `linkdef` (`linkid`,`name`,`recurses`) values ('98','member','N');

UNLOCK TABLES;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
